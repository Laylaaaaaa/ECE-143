import pandas as pd
import matplotlib.pyplot as plt

cpn1=['Matchtech Group plc.', 'JOBG8', 'JAM Recruitment Ltd', 'Michael Page Finance', 'BMS Sales Specialists LLP', 'London4Jobs', 'Jobsite Jobs', 'Randstad', 'UKStaffsearch', 'COREcruitment International', 'CVbrowser', 'Hays', 'ARRAY', 'Penguin Recruitment', 'Perfect Placement', 'Adecco Group', 'Adecco', 'Page Personnel Finance', 'Office Angels']
slr1=[44291, 44138, 43815, 43765, 40068, 39812, 39092, 37150, 34462, 34077, 32338, 31333, 29000, 27803, 25267, 22097, 22013, 21814, 20205]

width=0.7
plt.barh(cpn1,slr1,width,color='gb',align='center',alpha=0.4)
plt.xlabel('Average Salary')
plt.ylabel('Company')
plt.title('Average Salary per Company')
plt.show()