import pandas as pd
import matplotlib.pyplot as plt

lct1=['The City', 'London', 'Central London', 'South East London', 'Aberdeen', 'Berkshire', 'Surrey', 'Hampshire', 'West Midlands', 'East Sheen', 'Reading', 'UK', 'Bristol', 'Milton Keynes', 'Birmingham', 'Manchester', 'Belfast', 'Leeds', 'Nottingham', 'Sheffield']
slr1=[46528, 43429, 43407, 41530, 41175, 39639, 38520, 38129, 36319, 35441, 34878, 34113, 33481, 32166, 31103, 30109, 29586, 28934, 28831, 26476]

width=0.7
plt.barh(lct1,slr1,width,color='gb',align='center',alpha=0.4)
plt.xlabel('Average Salary')
plt.ylabel('Location')
plt.title('Average Salary per Location')
plt.show()