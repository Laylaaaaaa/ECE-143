import pandas as pd
import numpy as np
sly_ctg= pd.read_csv('Train_rev1.csv',usecols=[8,10])

ctg=list(sly_ctg.Category)
slr=list(sly_ctg.SalaryNormalized)
list1=list(zip(ctg,slr))

ctg1=[]
slr1=[]

for j in {'IT Jobs','Engineering Jobs','Accounting & Finance Jobs','Healthcare & Nursing Jobs','Sales Jobs','Other/General Jobs','Teaching Jobs','Hospitality & Catering Jobs','PR, Advertising & Marketing Jobs','Trade & Construction Jobs','HR & Recruitment Jobs','Admin Jobs','Retail Jobs','Customer Services Jobs','Legal Jobs','Manufacturing Jobs','Logistics & Warehouse Jobs','Social work Jobs','Consultancy Jobs','Travel Jobs'}:
	count=salary=av_slr=0
	for i in list1:
		if i[0] == j:
			count+=1
			salary+=i[1]
	av_slr=int(salary/count)
	ctg1.append(j)
	slr1.append(av_slr)

# print(ctg1)
# print(slr1)

dict1=dict(zip(ctg1,slr1))
dict2=dict(sorted(dict1.items(), key = lambda x:x[1],reverse = True))
ctg2=list(dict2.keys())
slr2=list(dict2.values())
print(dict2)
print(ctg2)
print(slr2)