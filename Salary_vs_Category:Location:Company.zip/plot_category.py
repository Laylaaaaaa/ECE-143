import pandas as pd
import matplotlib.pyplot as plt

ctg1=['IT Jobs', 'Legal Jobs', 'Accounting & Finance Jobs', 'Consultancy Jobs', 'Trade & Construction Jobs', 'Engineering Jobs', 'PR, Advertising & Marketing Jobs', 'Other/General Jobs', 'Retail Jobs', 'HR & Recruitment Jobs', 'Healthcare & Nursing Jobs', 'Social work Jobs', 'Sales Jobs', 'Teaching Jobs', 'Logistics & Warehouse Jobs', 'Manufacturing Jobs', 'Travel Jobs', 'Hospitality & Catering Jobs', 'Admin Jobs', 'Customer Services Jobs']
slr1=[43983, 42649, 38751, 37028, 36406, 35838, 35593, 35346, 32955, 32589, 32589, 32381, 30814, 27671, 26497, 26497, 23838, 23702, 21053, 19861]

width=0.7
plt.barh(ctg1,slr1,width,color='gb',align='center',alpha=0.4)
plt.xlabel('Average Salary')
plt.ylabel('Category')
plt.title('Average Salary per Category')
plt.show()