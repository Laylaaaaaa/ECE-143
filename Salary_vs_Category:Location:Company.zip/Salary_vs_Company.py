import pandas as pd
import numpy as np
sly_cpn= pd.read_csv('Train_rev1.csv',usecols=[7,10])

cpn=list(sly_cpn.Company)
slr=list(sly_cpn.SalaryNormalized)
list1=list(zip(cpn,slr))

cpn1=[]
slr1=[]

for j in {'UKStaffsearch','CVbrowser','London4Jobs','Hays','JAM Recruitment Ltd','Office Angels','Jobsite Jobs','Perfect Placement','ARRAY','JOBG8','Matchtech Group plc.','Penguin Recruitment','Randstad','Adecco','Michael Page Finance','Adecco Group','BMS Sales Specialists LLP','COREcruitment International','Page Personnel Finance'}:
	count=salary=av_slr=0
	for i in list1:
		if i[0] == j:
			count+=1
			salary+=i[1]
	av_slr=int(salary/count)
	cpn1.append(j)
	slr1.append(av_slr)

# print(cpn1)
# print(slr1)

dict1=dict(zip(cpn1,slr1))
dict2=dict(sorted(dict1.items(), key = lambda x:x[1],reverse = True))
cpn2=list(dict2.keys())
slr2=list(dict2.values())
print(dict2)
print(cpn2)
print(slr2)