import pandas as pd
import numpy as np
sly_lct= pd.read_csv('Train_rev1.csv',usecols=[4,10])

lct=list(sly_lct.LocationNormalized)
slr=list(sly_lct.SalaryNormalized)
list1=list(zip(lct,slr))

lct1=[]
slr1=[]

for j in {'UK','London','South East London','The City','Manchester','Leeds','Birmingham','Central London','West Midlands','Surrey','Reading','Bristol','Nottingham','Sheffield','Aberdeen','Hampshire','Belfast','East Sheen','Milton Keynes','Berkshire'}:
	count=salary=av_slr=0
	for i in list1:
		if i[0] == j:
			count+=1
			salary+=i[1]
	av_slr=int(salary/count)
	lct1.append(j)
	slr1.append(av_slr)

# print(lct1)
# print(slr1)

dict1=dict(zip(lct1,slr1))
dict2=dict(sorted(dict1.items(), key = lambda x:x[1],reverse = True))
lct2=list(dict2.keys())
slr2=list(dict2.values())
print(dict2)
print(lct2)
print(slr2)